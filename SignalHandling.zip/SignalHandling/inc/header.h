
#include<iostream>
#include<csignal>
#include<sys/wait.h>
#include<sys/types.h>
#include<unistd.h>



using namespace std;

