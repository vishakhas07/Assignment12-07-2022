#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <cstring>
#include<csignal>
#include<signal.h>
#define SIZE 40

using namespace std;

