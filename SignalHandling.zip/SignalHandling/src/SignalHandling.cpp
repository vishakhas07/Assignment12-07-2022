#include"header.h"

static void func(int signum)
{

	switch(signum)

	{

		case SIGSEGV:

			cout<<" signal number"<<signum<<endl;

			cout<<"sig fault error occured"<<endl;

			exit(EXIT_FAILURE);

			break;



		case SIGCHLD:

			cout<<"child signal is handled "<<endl;

			break;



		default:

			cout<<"Unhandled signal "<<endl;

	}
}


int main()
{

	int pid, status;

	pid=fork();




	
	if(pid == 0)

	{

		cout<<"child process starts with PID: "<<getpid()<<endl;

		cout<<"child process parent PID: "<<getppid()<<endl;

		for(;;);

	}

	else

	{

		signal(SIGCHLD, func);



		waitpid(pid, &status, 0);

		cout<<"Parent process PID : "<<getpid()<<endl;

		cout<<"Parent process PPID: "<<getppid()<<endl;

		if(raise(SIGCHLD) != 0)

		{	

			perror("raise() error");

			exit(EXIT_FAILURE);

		}

	}

	return EXIT_SUCCESS;

}
			
